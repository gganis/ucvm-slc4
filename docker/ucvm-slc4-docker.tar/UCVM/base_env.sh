export CERNVM_ENV=1
export PS1="\u@ucvm-slc4:\w \$ "

$BB echo "****************************************"
$BB echo "*** Welcome to SLC4 in CernVM+Docker ***"
$BB echo "****************************************"

$BB echo

$BB cat /etc/issue | $BB grep -v Kernel

cd /MIT

