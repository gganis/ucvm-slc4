# Cernlib
CERNLIB="/cvmfs/sft.cern.ch/lcg/external/cernlib/2005/slc4_ia32_gcc34"

$BB mkdir -p /cern/pro
CWD=$PWD
cd /cern/pro/
$BB ln -sf $CERNLIB/lib
$BB ln -sf $CERNLIB/bin
cd $CWD
export PATH=$CERNLIB/bin:$PATH
export LD_LIBRARY_PATH=$CERNLIB/lib:$LD_LIBRARY_PATH
